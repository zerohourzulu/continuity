export interface CaseLocation {historyFile:string;storage:string}
export declare function acquireHostLease(storage:string):Readonly<{assertOwned():void;release():void}>;
export declare function recoverDeadHost(storage:string):Readonly<{status:'DEAD_HOST_LEASE_REMOVED';historyChanged:false;authorityChanged:false}>;
export declare function inspectCase(location:CaseLocation):Readonly<{profile:string;eventCount:number;limits:{coreEvents:number;observationEvents:number;recordEntries:number};remainingCoreEvents:number;lateObservationCapacityAvailable:boolean;recordFiles:number;recordBytes:number;taskRequests:number;leasePresent:boolean;warnings:string[];pointInTimeOnly:true;restoreAuthorization:false}>;
export declare function snapshotCase(location:CaseLocation&{directory:string}):Readonly<{status:'PRIVATE_SNAPSHOT_CREATED';files:number;restoreAuthorized:false}>;
export declare function verifySnapshot(directory:string):Readonly<{status:'PRIVATE_SNAPSHOT_VERIFIED';files:number;eventCount:number;currentnessEstablished:false;restoreAuthorized:false}>;
